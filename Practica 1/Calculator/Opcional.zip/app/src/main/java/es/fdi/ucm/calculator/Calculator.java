package es.fdi.ucm.calculator;

import android.widget.EditText;

public class Calculator {
    public double addNumbers(double  x, double y) {
        return x + y;
    }
}
